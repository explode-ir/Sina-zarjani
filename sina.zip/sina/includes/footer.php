</td>
                </tr>
            </table>

            
            <table style="width: 100%;"  border="1"  >
                <tr>
                	<td style="text-align:center">مالكيت مادی و معنوی سايت</td>
                </tr>
            </table>

        </td>
    </tr>
</table>

</body>
</html>
